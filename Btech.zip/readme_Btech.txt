Btech

For producing the results of Critical values of LRT test for various values of n and alpha we have the function named "Print_critical_values_for_LRT"
where it takes only alpha as a input and will all Critical values corresponding to each alpha (column wise acoording to table ).
so.Print_Critical_value_for_LRT(0.01) will print first column of the table and so on.

Similarly,
For producing the results of Critical values of SIC test for various values of n and alpha we have the function named "Print_critical_values_for_SIC"
where it takes only alpha as a input and will all Critical values corresponding to each alpha (column wise acoording to table ).
so.Print_Critical_value_for_SIC(0.01) will print first column of the table and so on.


