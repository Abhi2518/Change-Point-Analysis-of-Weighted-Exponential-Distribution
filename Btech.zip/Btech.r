set.seed(10)


#defining u as a function of n which is required in calculating the critical values of LRT test ussing
# theorem by Csorgo and Horvath in 1997.
u<-function(n){
    k <- (n^2-2*floor(log(n))*n+(2*floor(log(n)))^2)/(2*floor(log(n)))^2
    return (k)
}


#defining A  and B as a function of n which is stated in theorem by Csorgo and Horvath in 1997 which will 
# be used in calculating the critical values of LRT and SIC tests.
A<-function(t){
    a<-(2*log(t))^(1/2)
    return (a)
}


B<-function(t){
    a<-2*log(t)+log(log(t))
    return(a)
}


#function for Critical Value for LRT test
Critical_LRT_value<-function(alpha,n){
    c<-((log(-log(1-alpha+exp(-exp(B(log(u(n)))))))-B(log(u(n))))/(-A(log(u(n)))))^2
    return(c)
}


#function for Critical Value for SIC test
Critical_SIC_value<-function(alpha,n){
    d<-((B(log(n))-log(log((1-alpha+exp(-(2*exp(B(log(n))))))^(-1/2))))/A(log(n)))^2-2*log(n)
    return(d)
}


#function to print the critical values for LRT test for given significance level and sample size n
Print_critical_values_for_LRT<-function(alpha){
c<-numeric(length=16)
    n=50
    for(i in 1:16){
        c[i]=Critical_LRT_value(alpha,n)
        n<- n + 10
    }
    return (c)
}


#function to print the critical values for SIC for given significance level and sample size n
Print_critical_values_for_SIC<-function(alpha){
    c<-numeric(length=16)
    n=30
    for(i in 1:8){
        c[i]=Critical_SIC_value(alpha,n)
        n<-n+10
    }
    n<-n+40
    for(i in 9:16){
        c[i]=Critical_SIC_value(alpha,n)
        n<-n+50
    }
    return (c)
}

# An attempt to calculate critical values for MIC using BOOTSTRAPPING method


# Defining the Weighted Exponential Distribution Function

WE_density_func<-function(beta,lambda,x){
    d<-((beta+lambda)lambda(exp(-lambda*x))*(1-exp(-beta*x)))/beta
    return (d)
}


# Function to sample from exponential distribution function with given beta and lambda using A-R Sampling
# With Proposal distribution Exponential(lambda)

Sampling_from_WE<-function(n,beta,lambda){
    x<-numeric(length=n)
    c<-(beta+lambda)/beta
    for(i in 1:n){
        accept<-0
        while(accept==0){
            U<-runif(1)
            prop<-rexp(1,rate=lambda)
            ratio<-(WE_density_func(beta,lambda,prop))/((dexp(prop,rate=lambda))*c)
            if(U<=ratio){
                accept<-1
                x[i]=prop
            }
        }
    }
    return(x)
}

#using GA for estimating the parameters beta and lambda

estimator_using_GA<-function(c,n){
esti<-numeric(length=2)
esti1<-numeric(length=2)
    esti[1]<-sum(c)/4
    esti[2]<-sum(c)*3/4
    esti1[1]<-esti[1]+t(n/(esti[1]+esti[2])-n/esti[1]+sum(c/((exp(esti[1]*c))-1)))
    esti1[2]<-esti[2]+t(n/(esti[1]+esti[2])+n/esti[2]-sum(c))
    
    error<-1e-3
    t<-0.001
    while(sqrt((esti1[1]-esti[1])^2+(esti1[2]-esti[2])^2)>=error){
    esti[1]<-esti1[1]
    esti[2]<-esti1[2]
    j<-esti1[1]
    esti1[1]<-esti1[1]+t(n/(esti1[1]+esti1[2])-n/esti1[1]+sum(c/((exp(esti1[1]*c))-1)))
    esti1[2]<-esti1[2]+t(n/(j+esti1[2])+n/esti1[2]-sum(c))
    }
    return (esti1)
}

#function for evaluating test statistic for corresponding value
test<-function(E,x,n){
    c<- (-2*(n*log(sum(E))+n*log(E[2])-n*log(E[1])-E[1]*sum(E)+sum(log(1-exp(-E[1]*x)))))
    return (c)
}

sum1<-function(s,e,c,n,beta,lambda){
r<-0
    for(i in s:e){
        r<-r+lambda*c[i]-log(1-(exp(-beta*c[i])))
    }
    return (r)
}

sum2<-function(c,n,s,e){
    r<-0
    for(i in s:e){
        r<-r+c[i]
    }
    return (r)
}

sum3<-function(c,n,s,e,beta){
    r<-0
    for(i in s:e){
        r<-r+(c[i]*(exp(-beta*c[i])))/(1-(exp(-beta*c[i])))
    }
}

#min_MIC corresponding to alternate hypothesis under NULL.


min_MIC<-function(c,n){
    beta_1<-numeric(length=n)
    beta_n<-numeric(length=n)
    lambda_1<-numeric(length=n)
    lambda_n<-numeric(length=n)

    for(k in 2:n-1){
        esti_1<-numeric(length=2)
        esti1_1<-numeric(length=2)
        esti_n<-numeric(length=2)
        esti1_n<-numeric(length=2)
        
    esti_1[1]<-sum2(c,n,1,k)/4
    esti_1[2]<-sum2(c,n,1,k)*3/4
    esti1_1[1]<-esti_1[1]+t(k/(esti_1[1]+esti_1[2])-k/esti_1[1]+sum3(c,n,1,k,esti_1[1]))
    esti1_1[2]<-esti_1[2]+t(k/(esti[1]+esti[2])+k/esti[2]-sum2(c,n,1,k))
    
    esti_n[1]<-sum2(c,n,k+1,n)/4
    esti_n[2]<-sum2(c,n,k+1,n)*3/4
    esti1_n[1]<-esti_n[1]+t((n-k)/(esti_n[1]+esti_n[2])-(n-k)/esti_n[1]+sum3(c,n,k+1,n,esti_n[1]))
    esti1_n[2]<-esti_n[2]+t((n-k)/(esti_n[1]+esti_n[2])+(n-k)/esti_n[2]-sum2(c,n,k+1,n))
    
    error<-1e-3
    t<-0.001
    while(sqrt((esti1_1[1]-esti_1[1])^2+(esti1_1[2]-esti_1[2])^2)>=error){
    esti_1[1]<-esti1_1[1]
    esti_1[2]<-esti1_1[2]
    j<-esti1_1[1]
    esti1_1[1]<-esti1_1[1]+t(k/(esti1_1[1]+esti1_1[2])-k/esti1_1[1]+sum3(c,n,1,k,esti1_1[1]))
    esti1_1[2]<-esti1_1[2]+t(k/(j+esti1_1[2])+k/esti1_1[2]-sum2(c,n,1,k))
    }
    
    beta_1[k]=esti1_1[1]
    lambda_1[k]=esti1_1[2]
    
    
    while(sqrt((esti1_n[1]-esti_n[1])^2+(esti1_n[2]-esti_n[2])^2)>=error){
    esti_n[1]<-esti1_n[1]
    esti_n[2]<-esti1_n[2]
    j<-esti1_n[1]
    esti1_n[1]<-esti1_n[1]+t((n-k)/(esti1_n[1]+esti1_1[2])-(n-k)/esti1_n[1]+sum3(c,n,k+1,n,esti1_n[1]))
    esti1_n[2]<-esti1_n[2]+t((n-k)/(j+esti1_n[2])+(n-k)/esti1_n[2]-sum2(c,n,k+1,n))
    }
    
    beta_n[k]=esti1_n[k]
    lambda_n[k]=esti1_n[k]
    }
    
    MIC_H1<-numeric(length=n-2)
    t<-1
    for(k in 2:n-1){
        MIC_H1[t]= (((2*k/n)-1)^2)*log(n)-2*(k*(log(beta_1[k]+lambda_1[k])+log(lambda_1[k])-log(beta_1[k]))-sum1(1,k,c,n,beta_1[k],lambda_1[k])+(n-k)*(log(beta_n[k]+lambda_n[k])+log(lambda_n[k])-log(beta_n[k]))-sum1(k+1,n,c,n,beta_n[k],lambda_n[k])) 
    t<-t+1
    }
    return (min(MIC_H1))
}



#overall function to determine the Critical value of MIC for given significance level using BOOTSTRAPPING


Critical_MIC_value<-function(alpha,beta,lambda,n){
s<-Sampling_from_WE(n,beta,lambda)
B<-1e3
f<-numeric(length=B)
    for(i in 1:B){
        x<-sample(s,replace=TRUE)
        E_Ho<-estimator_using_GA(x,n)
        f[i]<-test(E_Ho,x,n)-min_MIC(x,n)
    }
   return (f[floor((1-alpha/2)*B)]) 
  }





